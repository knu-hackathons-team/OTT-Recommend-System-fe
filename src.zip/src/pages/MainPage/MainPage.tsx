import React from "react";

const MainPage: React.FC = () => {
  return (
    <div>
      <h1>Main Page</h1>
      <p>Welcome to the main page!</p>
    </div>
  );
};

export default MainPage;
