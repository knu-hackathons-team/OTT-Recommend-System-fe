export const RouterPath = {
  root: "/",
  main: "/", // 메인 페이지
};
