export const RouterPath = {
  root: "/",
  main: "/main", // 메인 페이지
  rediretcion: "/redirection", // 카카오 로그인 리다이렉션 페이지
};
